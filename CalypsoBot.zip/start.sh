nodemon app.js
